import React, { useState, useEffect, useRef } from 'react';
import { sound } from '../utils/audio.ts';
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  Camera,
  Sparkles,
  X,
  Heart,
  Trash2,
  RotateCcw,
} from 'lucide-react';
import { PolaroidPhoto } from '../types.ts';
import {
  subscribeToSharedPolaroids,
  addSharedPolaroid,
  deleteSharedPolaroid,
  restoreDefaultPolaroids,
  DEFAULT_POLAROIDS,
} from '../firebase.ts';

interface PolaroidCarouselProps {
  onClose?: () => void;
}

export const PolaroidCarousel: React.FC<PolaroidCarouselProps> = ({ onClose }) => {
  const [photos, setPhotos] = useState<PolaroidPhoto[]>(() => {
    try {
      const saved = localStorage.getItem('birthday_polaroid_memories');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {}
    return DEFAULT_POLAROIDS;
  });

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAdding, setIsAdding] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [newTitle, setNewTitle] = useState('');
  const [newCaption, setNewCaption] = useState('');
  const [newDate, setNewDate] = useState('');
  const [newImageBase64, setNewImageBase64] = useState<string>('');
  const touchStartX = useRef<number | null>(null);

  // Live real-time Firestore sync across all users and all devices
  useEffect(() => {
    const unsubscribe = subscribeToSharedPolaroids(livePhotos => {
      setPhotos(livePhotos);
    });
    return () => unsubscribe();
  }, []);

  const handleNext = () => {
    if (photos.length <= 1) return;
    sound.playButtonTap();
    setCurrentIndex(prev => (prev + 1) % photos.length);
  };

  const handlePrev = () => {
    if (photos.length <= 1) return;
    sound.playButtonTap();
    setCurrentIndex(prev => (prev - 1 + photos.length) % photos.length);
  };

  // Permanently delete any photo (including 2nd pic) for all users via Firestore
  const handleDeletePhoto = async (id: string) => {
    sound.playButtonTap();
    setDeleteConfirmId(null);
    const updated = photos.filter(p => p.id !== id);
    setPhotos(updated);
    if (currentIndex >= updated.length) {
      setCurrentIndex(Math.max(0, updated.length - 1));
    }
    try {
      await deleteSharedPolaroid(id);
    } catch (e) {
      console.warn('Error deleting shared photo:', e);
    }
  };

  // Restore defaults in Firestore so all users see original collection again
  const handleResetDefaults = async () => {
    sound.playButtonTap();
    sound.playMagicalChime();
    setPhotos(DEFAULT_POLAROIDS);
    setCurrentIndex(0);
    try {
      await restoreDefaultPolaroids();
    } catch (e) {
      console.warn('Error restoring default photos:', e);
    }
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const diff = e.changedTouches[0].clientX - touchStartX.current;
    if (diff > 45) {
      handlePrev();
    } else if (diff < -45) {
      handleNext();
    }
    touchStartX.current = null;
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      if (event.target?.result) {
        setNewImageBase64(event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  // Save new memory photo permanently to Firestore for all users
  const handleSavePhoto = async () => {
    if (!newCaption.trim()) return;

    sound.playButtonTap();
    sound.playMagicalChime();

    const newPhotoData = {
      title: newTitle.trim() || 'A Precious Memory',
      caption: newCaption.trim(),
      date: newDate.trim() || new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
      imageUrl: newImageBase64 || undefined,
      theme: 'custom' as const,
    };

    setIsAdding(false);
    setNewTitle('');
    setNewCaption('');
    setNewDate('');
    setNewImageBase64('');

    try {
      const saved = await addSharedPolaroid(newPhotoData);
      setPhotos(prev => [saved, ...prev.filter(p => p.id !== saved.id)]);
      setCurrentIndex(0);
    } catch (e) {
      console.warn('Error saving shared photo:', e);
    }
  };

  const currentPhoto = photos[currentIndex] || photos[0] || null;

  // Aesthetic, clean, responsive illustrations (1:1 square vector graphics)
  const renderIllustration = (theme: PolaroidPhoto['theme'], customImg?: string) => {
    if (customImg) {
      return (
        <img
          src={customImg}
          alt="Personal memory"
          className="w-full h-full object-cover rounded-lg"
        />
      );
    }

    switch (theme) {
      case 'starlight':
        // 1st Picture: Celestial Midnight Constellation (Clean, poetic, aesthetic)
        return (
          <div className="relative w-full h-full bg-[#050816] flex items-center justify-center overflow-hidden rounded-lg">
            <svg viewBox="0 0 320 320" className="w-full h-full" preserveAspectRatio="xMidYMid slice">
              <defs>
                <radialGradient id="skyGrad" cx="50%" cy="30%" r="80%">
                  <stop offset="0%" stopColor="#141a3a" />
                  <stop offset="50%" stopColor="#0a0e26" />
                  <stop offset="100%" stopColor="#040612" />
                </radialGradient>
                <radialGradient id="nebulaGlow" cx="50%" cy="45%" r="60%">
                  <stop offset="0%" stopColor="#6366f1" stopOpacity="0.25" />
                  <stop offset="50%" stopColor="#ec4899" stopOpacity="0.1" />
                  <stop offset="100%" stopColor="#040612" stopOpacity="0" />
                </radialGradient>
                <radialGradient id="moonHalo" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#fef08a" stopOpacity="0.6" />
                  <stop offset="50%" stopColor="#f59e0b" stopOpacity="0.2" />
                  <stop offset="100%" stopColor="#040612" stopOpacity="0" />
                </radialGradient>
                <linearGradient id="moonGold" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#fffbeb" />
                  <stop offset="50%" stopColor="#fef08a" />
                  <stop offset="100%" stopColor="#f59e0b" />
                </linearGradient>
                <linearGradient id="hillGrad1" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#0f162e" />
                  <stop offset="100%" stopColor="#070a16" />
                </linearGradient>
                <linearGradient id="hillGrad2" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#080c1a" />
                  <stop offset="100%" stopColor="#030408" />
                </linearGradient>
              </defs>

              {/* Sky Background */}
              <rect width="320" height="320" fill="url(#skyGrad)" />
              <rect width="320" height="320" fill="url(#nebulaGlow)" />

              {/* Glowing Golden Crescent Moon */}
              <circle cx="236" cy="68" r="42" fill="url(#moonHalo)" />
              <path
                d="M 248 42 C 230 46 218 62 220 82 C 222 100 236 114 254 114 C 238 116 220 106 214 90 C 208 72 216 52 232 44 C 238 41 243 41 248 42 Z"
                fill="url(#moonGold)"
                filter="drop-shadow(0 0 8px rgba(253, 224, 71, 0.7))"
              />

              {/* Delicate Constellation of Wishes */}
              <path
                d="M 65 110 L 110 80 L 160 95 L 195 125 L 160 160 L 105 145 Z"
                fill="none"
                stroke="#fde047"
                strokeWidth="0.9"
                strokeDasharray="3 3"
                opacity="0.65"
              />
              {/* Star Nodes */}
              <circle cx="65" cy="110" r="3" fill="#ffffff" filter="drop-shadow(0 0 5px #fde047)" />
              <circle cx="110" cy="80" r="3.5" fill="#ffffff" filter="drop-shadow(0 0 6px #fde047)" />
              <circle cx="160" cy="95" r="3" fill="#ffffff" filter="drop-shadow(0 0 5px #fde047)" />
              <circle cx="195" cy="125" r="3.5" fill="#ffffff" filter="drop-shadow(0 0 6px #fde047)" />
              <circle cx="160" cy="160" r="3" fill="#ffffff" filter="drop-shadow(0 0 5px #fde047)" />
              <circle cx="105" cy="145" r="3" fill="#ffffff" filter="drop-shadow(0 0 5px #fde047)" />

              {/* Luminous Diamond 4-Point Stars */}
              <path d="M 110 70 Q 110 80 120 80 Q 110 80 110 90 Q 110 80 100 80 Q 110 80 110 70 Z" fill="#ffffff" opacity="0.9" />
              <path d="M 195 117 Q 195 125 203 125 Q 195 125 195 133 Q 195 125 187 125 Q 195 125 195 117 Z" fill="#fef08a" opacity="0.85" />
              <path d="M 70 50 Q 70 56 76 56 Q 70 56 70 62 Q 70 56 64 56 Q 70 56 70 50 Z" fill="#fef08a" opacity="0.75" />

              {/* Gentle ambient stardust */}
              <circle cx="45" cy="75" r="1.5" fill="#fde047" opacity="0.8" />
              <circle cx="85" cy="180" r="1.2" fill="#ffffff" opacity="0.7" />
              <circle cx="140" cy="45" r="1.8" fill="#fef08a" opacity="0.85" />
              <circle cx="175" cy="65" r="1.2" fill="#ffffff" opacity="0.6" />
              <circle cx="280" cy="95" r="1.5" fill="#fde047" opacity="0.7" />
              <circle cx="265" cy="150" r="1.8" fill="#fef08a" opacity="0.8" />
              <circle cx="50" cy="155" r="1" fill="#ffffff" opacity="0.5" />
              <circle cx="225" cy="185" r="1.4" fill="#fde047" opacity="0.6" />

              {/* Serene Fairytale Ridge Silhouette */}
              <path d="M 0 240 Q 90 215 180 230 Q 250 220 320 245 L 320 320 L 0 320 Z" fill="url(#hillGrad1)" />
              {/* Silhouette Pine Trees */}
              <path d="M 45 235 L 49 220 L 53 235 Z" fill="#070a16" />
              <path d="M 43 230 L 49 214 L 55 230 Z" fill="#070a16" />
              <path d="M 68 245 L 72 232 L 76 245 Z" fill="#070a16" />
              <path d="M 260 242 L 264 226 L 268 242 Z" fill="#070a16" />
              <path d="M 275 250 L 278 238 L 282 250 Z" fill="#070a16" />

              {/* Foreground Soft Hill */}
              <path d="M 0 265 Q 120 245 240 260 Q 285 255 320 270 L 320 320 L 0 320 Z" fill="url(#hillGrad2)" />
            </svg>
          </div>
        );

      case 'cake':
        // 2nd Picture: A Cake of Blessings (Clean, luxurious, gourmet)
        return (
          <div className="relative w-full h-full bg-[#150d1e] flex items-center justify-center overflow-hidden rounded-lg">
            <svg viewBox="0 0 320 320" className="w-full h-full" preserveAspectRatio="xMidYMid slice">
              <defs>
                <radialGradient id="cakeBg" cx="50%" cy="40%" r="75%">
                  <stop offset="0%" stopColor="#2a163a" />
                  <stop offset="60%" stopColor="#180c22" />
                  <stop offset="100%" stopColor="#0d0614" />
                </radialGradient>
                <radialGradient id="candleGlowHalo" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#fef08a" stopOpacity="0.8" />
                  <stop offset="40%" stopColor="#f59e0b" stopOpacity="0.35" />
                  <stop offset="100%" stopColor="#f97316" stopOpacity="0" />
                </radialGradient>
                <linearGradient id="pedestalGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#ca8a04" />
                  <stop offset="50%" stopColor="#fef08a" />
                  <stop offset="100%" stopColor="#a16207" />
                </linearGradient>
                <linearGradient id="bottomFrosting" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#fffbeb" />
                  <stop offset="100%" stopColor="#fde68a" />
                </linearGradient>
                <linearGradient id="topFrosting" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#fff8f8" />
                  <stop offset="100%" stopColor="#fbcfe8" />
                </linearGradient>
                <linearGradient id="berryRed" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#f43f5e" />
                  <stop offset="100%" stopColor="#9f1239" />
                </linearGradient>
              </defs>

              <rect width="320" height="320" fill="url(#cakeBg)" />

              {/* Ambient celebratory golden sparkles */}
              <circle cx="55" cy="70" r="1.5" fill="#fde047" opacity="0.7" />
              <circle cx="80" cy="120" r="1.2" fill="#ffffff" opacity="0.6" />
              <circle cx="260" cy="85" r="1.5" fill="#fde047" opacity="0.7" />
              <circle cx="240" cy="140" r="1.2" fill="#fef08a" opacity="0.6" />
              <path d="M 65 95 L 65 103 M 61 99 L 69 99" stroke="#fde047" strokeWidth="0.9" opacity="0.7" />
              <path d="M 255 110 L 255 118 M 251 114 L 259 114" stroke="#fef08a" strokeWidth="0.9" opacity="0.7" />

              {/* Golden Porcelain Cake Pedestal Stand */}
              <ellipse cx="160" cy="250" rx="90" ry="16" fill="url(#pedestalGrad)" />
              <ellipse cx="160" cy="247" rx="84" ry="13" fill="#fdfbf7" opacity="0.95" />

              {/* Bottom Tier Base */}
              <path d="M 85 190 C 85 190 85 230 85 230 C 85 240 118 245 160 245 C 202 245 235 240 235 230 L 235 190 Z" fill="#d97706" opacity="0.8" />
              <path d="M 85 190 C 85 190 85 226 85 226 C 85 236 118 242 160 242 C 202 242 235 236 235 226 L 235 190 Z" fill="url(#bottomFrosting)" />
              <ellipse cx="160" cy="190" rx="75" ry="15" fill="#fffdfa" />

              {/* Bottom tier decorative frosting scallops */}
              <path d="M 85 192 Q 100 204 115 192 Q 130 204 145 192 Q 160 205 175 192 Q 190 204 205 192 Q 220 204 235 192" fill="none" stroke="#f472b6" strokeWidth="3" strokeLinecap="round" />

              {/* Top Tier Base */}
              <path d="M 110 145 C 110 145 110 180 110 180 C 110 188 132 192 160 192 C 188 192 210 188 210 180 L 210 145 Z" fill="#f59e0b" opacity="0.85" />
              <path d="M 110 145 C 110 145 110 176 110 176 C 110 184 132 189 160 189 C 188 189 210 184 210 176 L 210 145 Z" fill="url(#topFrosting)" />
              <ellipse cx="160" cy="145" rx="50" ry="11" fill="#ffffff" />

              {/* Top tier delicate pink scallops */}
              <path d="M 110 147 Q 122 155 135 147 Q 148 156 160 147 Q 172 156 185 147 Q 198 155 210 147" fill="none" stroke="#fb7185" strokeWidth="2.5" strokeLinecap="round" />

              {/* Fresh ruby berries along top rim */}
              <circle cx="125" cy="143" r="4.5" fill="url(#berryRed)" />
              <circle cx="142" cy="146" r="4.2" fill="url(#berryRed)" />
              <circle cx="178" cy="146" r="4.2" fill="url(#berryRed)" />
              <circle cx="195" cy="143" r="4.5" fill="url(#berryRed)" />

              {/* Center Birthday Candle */}
              <rect x="156" y="98" width="8" height="42" rx="3" fill="#ffffff" stroke="#fde047" strokeWidth="0.8" />
              {/* Gold candle spiral stripes */}
              <path d="M 156 108 L 164 112 M 156 118 L 164 122 M 156 128 L 164 132" stroke="#f59e0b" strokeWidth="1.6" strokeLinecap="round" />
              {/* Wick */}
              <line x1="160" y1="98" x2="160" y2="88" stroke="#334155" strokeWidth="1.5" />

              {/* Enchanted Candle Flame & Warm Glow */}
              <circle cx="160" cy="78" r="30" fill="url(#candleGlowHalo)" />
              {/* Outer orange flame */}
              <path d="M 160 64 C 154 74 151 81 154 87 C 157 91 163 91 166 87 C 169 81 166 74 160 64 Z" fill="#f97316" />
              {/* Inner golden flame */}
              <path d="M 160 70 C 156 77 155 82 157 85 C 159 87 161 87 163 85 C 165 82 164 77 160 70 Z" fill="#fef08a" />
              <ellipse cx="160" cy="83" rx="1.6" ry="2.5" fill="#ffffff" />
            </svg>
          </div>
        );

      case 'sunset':
        // 3rd Picture: Chasing Golden Sunsets
        return (
          <div className="relative w-full h-full bg-[#200f1c] flex items-center justify-center overflow-hidden rounded-lg">
            <svg viewBox="0 0 320 320" className="w-full h-full" preserveAspectRatio="xMidYMid slice">
              <defs>
                <linearGradient id="sunsetSky" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#2e0e22" />
                  <stop offset="40%" stopColor="#5d1f2b" />
                  <stop offset="70%" stopColor="#9a3412" />
                  <stop offset="100%" stopColor="#ea580c" />
                </linearGradient>
                <radialGradient id="sunGlow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#fef08a" stopOpacity="1" />
                  <stop offset="40%" stopColor="#f59e0b" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#f97316" stopOpacity="0" />
                </radialGradient>
              </defs>
              <rect width="320" height="320" fill="url(#sunsetSky)" />
              {/* Golden Sun & Halo */}
              <circle cx="160" cy="180" r="50" fill="url(#sunGlow)" />
              <circle cx="160" cy="180" r="28" fill="#fef08a" />
              {/* Sea Horizon & Water Ripples */}
              <rect x="0" y="210" width="320" height="110" fill="#1b0c1e" />
              <line x1="120" y1="225" x2="200" y2="225" stroke="#fde047" strokeWidth="1.8" opacity="0.8" strokeLinecap="round" />
              <line x1="135" y1="235" x2="185" y2="235" stroke="#fde047" strokeWidth="1.5" opacity="0.6" strokeLinecap="round" />
              <line x1="145" y1="245" x2="175" y2="245" stroke="#fed7aa" strokeWidth="1.2" opacity="0.4" strokeLinecap="round" />
              {/* Silhouetted Soaring Birds */}
              <path d="M 65 110 Q 72 104 80 110 Q 88 104 95 110" fill="none" stroke="#fed7aa" strokeWidth="1.4" opacity="0.8" />
              <path d="M 195 90 Q 200 85 206 90 Q 212 85 218 90" fill="none" stroke="#fed7aa" strokeWidth="1.2" opacity="0.7" />
            </svg>
          </div>
        );

      case 'cat':
        // 4th Picture: Warm Paws & Little Wonders
        return (
          <div className="relative w-full h-full bg-[#12131f] flex items-center justify-center overflow-hidden rounded-lg">
            <svg viewBox="0 0 320 320" className="w-full h-full" preserveAspectRatio="xMidYMid slice">
              <defs>
                <radialGradient id="catBgGlow" cx="50%" cy="50%" r="60%">
                  <stop offset="0%" stopColor="#252542" />
                  <stop offset="100%" stopColor="#0d0e17" />
                </radialGradient>
              </defs>
              <rect width="320" height="320" fill="url(#catBgGlow)" />
              {/* Ambient stars and hearts */}
              <circle cx="60" cy="65" r="1.5" fill="#fde047" opacity="0.8" />
              <circle cx="260" cy="80" r="1.5" fill="#fde047" opacity="0.8" />
              <path d="M 215 95 C 215 90 220 85 225 90 C 230 85 235 90 235 95 C 235 102 225 108 225 108 C 225 108 215 102 215 95 Z" fill="#f43f5e" opacity="0.75" />
              {/* Cozy Kitten curled peacefully */}
              <ellipse cx="160" cy="205" rx="65" ry="42" fill="#f59445" />
              <ellipse cx="160" cy="208" rx="42" ry="26" fill="#fed7aa" />
              <circle cx="125" cy="180" r="32" fill="#f59445" />
              {/* Ears */}
              <polygon points="105,160 115,130 130,154" fill="#f59445" />
              <polygon points="110,158 116,138 126,154" fill="#fbcfe8" />
              <polygon points="135,155 148,132 155,160" fill="#f59445" />
              <polygon points="139,155 147,138 152,158" fill="#fbcfe8" />
              {/* Sleeping cute eyes */}
              <path d="M 112 178 Q 118 184 124 178" fill="none" stroke="#1e293b" strokeWidth="2" strokeLinecap="round" />
              <path d="M 134 178 Q 140 184 146 178" fill="none" stroke="#1e293b" strokeWidth="2" strokeLinecap="round" />
              {/* Nose & Mouth */}
              <polygon points="128,187 132,187 130,190" fill="#f43f5e" />
              <path d="M 126 192 Q 130 195 134 192" fill="none" stroke="#1e293b" strokeWidth="1.2" />
              {/* Curled Tail */}
              <path d="M 220 205 Q 240 180 230 160" fill="none" stroke="#ea580c" strokeWidth="8" strokeLinecap="round" />
            </svg>
          </div>
        );

      case 'lantern':
      default:
        // 5th Picture: Lanterns of Hope
        return (
          <div className="relative w-full h-full bg-[#080d19] flex items-center justify-center overflow-hidden rounded-lg">
            <svg viewBox="0 0 320 320" className="w-full h-full" preserveAspectRatio="xMidYMid slice">
              <defs>
                <radialGradient id="lanternSky" cx="50%" cy="50%" r="70%">
                  <stop offset="0%" stopColor="#14213d" />
                  <stop offset="100%" stopColor="#050811" />
                </radialGradient>
                <radialGradient id="lanternGlow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#fef08a" />
                  <stop offset="50%" stopColor="#f59e0b" stopOpacity="0.85" />
                  <stop offset="100%" stopColor="#b45309" stopOpacity="0" />
                </radialGradient>
              </defs>
              <rect width="320" height="320" fill="url(#lanternSky)" />
              {/* Distant stars */}
              <circle cx="45" cy="50" r="1.5" fill="#fde047" opacity="0.8" />
              <circle cx="275" cy="70" r="1.5" fill="#fde047" opacity="0.8" />
              <circle cx="90" cy="130" r="1.2" fill="#ffffff" opacity="0.6" />
              <circle cx="230" cy="140" r="1.2" fill="#ffffff" opacity="0.6" />
              {/* Distant floating lantern */}
              <ellipse cx="235" cy="95" rx="14" ry="19" fill="#f59e0b" opacity="0.8" />
              <ellipse cx="235" cy="95" rx="9" ry="14" fill="#fef08a" opacity="0.9" />
              {/* Center Main Luminous Lantern */}
              <circle cx="160" cy="165" r="50" fill="url(#lanternGlow)" opacity="0.5" />
              <ellipse cx="160" cy="165" rx="36" ry="48" fill="#f59e0b" opacity="0.9" />
              <ellipse cx="160" cy="165" rx="24" ry="36" fill="#fef08a" />
              {/* Wooden caps & red tassel */}
              <rect x="145" y="114" width="30" height="5" rx="2" fill="#78350f" />
              <rect x="145" y="211" width="30" height="5" rx="2" fill="#78350f" />
              <line x1="160" y1="216" x2="160" y2="238" stroke="#dc2626" strokeWidth="2.5" />
            </svg>
          </div>
        );
    }
  };

  return (
    <div className="relative w-full max-w-sm sm:max-w-md mx-auto flex flex-col items-center select-none">
      {/* Top Header bar with Close & Add Memory action */}
      <div className="w-full flex items-center justify-between mb-2.5 px-2">
        <div className="flex items-center gap-2">
          <Camera className="w-4 h-4 text-[#d4af37]" />
          <span className="text-xs font-serif font-semibold text-[#f5e6b3] uppercase tracking-wider">
            Polaroid Memories {photos.length > 0 ? `(${currentIndex + 1}/${photos.length})` : '(0)'}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            id="add-polaroid-memory-btn"
            onClick={() => {
              sound.playButtonTap();
              setIsAdding(true);
            }}
            className="min-h-[36px] px-3 py-1 rounded-full bg-white/[0.06] hover:bg-white/[0.12] border border-amber-400/30 text-amber-200 text-xs font-serif flex items-center gap-1.5 cursor-pointer transition-all hover:scale-105 active:scale-95 shadow-sm"
            title="Add a custom memory photo"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Memory</span>
          </button>
          {onClose && (
            <button
              onClick={() => {
                sound.playButtonTap();
                onClose();
              }}
              className="min-h-[36px] min-w-[36px] rounded-full bg-white/[0.04] hover:bg-white/[0.1] text-slate-300 hover:text-white flex items-center justify-center cursor-pointer transition-colors"
              title="Close Album"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {photos.length === 0 ? (
        /* Empty State */
        <div className="relative w-full max-w-[310px] sm:max-w-[340px] bg-[#fdfbf7] text-stone-900 rounded-2xl p-6 shadow-2xl flex flex-col items-center justify-center text-center select-none border border-stone-200 animate-fadeIn">
          <div className="w-14 h-14 rounded-full bg-stone-100 border border-stone-200 flex items-center justify-center mb-3 text-stone-400">
            <Camera className="w-7 h-7" />
          </div>
          <h3 className="font-serif font-bold text-base text-stone-800">Album is Empty</h3>
          <p className="text-xs text-stone-600 font-serif italic mt-1.5 max-w-[220px] leading-relaxed">
            All photos have been removed. You can add a new photo or restore the original collection.
          </p>
          <div className="mt-5 flex flex-col gap-2.5 w-full max-w-[220px]">
            <button
              onClick={() => {
                sound.playButtonTap();
                setIsAdding(true);
              }}
              className="min-h-[44px] px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-serif font-semibold text-xs tracking-wider uppercase transition-all cursor-pointer shadow-md active:scale-95 flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add Memory</span>
            </button>
            <button
              onClick={handleResetDefaults}
              className="min-h-[44px] px-4 py-2.5 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-700 font-serif text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Restore Defaults</span>
            </button>
          </div>
        </div>
      ) : currentPhoto && (
        /* Main Polaroid Frame Container (Optimized for Mobile & PC) */
        <div
          className="relative w-full max-w-[310px] sm:max-w-[340px] bg-[#fdfbf7] text-stone-900 rounded-2xl p-3 sm:p-4 shadow-[0_20px_50px_rgba(0,0,0,0.85),0_0_0_1px_rgba(255,255,255,0.15)] flex flex-col justify-between transition-all duration-300 hover:rotate-0 rotate-[-1deg] select-none"
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        >
          {/* Vintage Golden Brass Pin at Top */}
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center">
            <div className="w-4 h-4 rounded-full bg-gradient-to-br from-amber-200 via-amber-400 to-amber-600 shadow-md border border-amber-300 flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-amber-900" />
            </div>
          </div>

          {/* Polaroid Inner Photo Canvas (1:1 Square) */}
          <div className="relative w-full aspect-square rounded-lg overflow-hidden bg-[#0c0e17] shadow-inner border border-stone-200">
            {renderIllustration(currentPhoto.theme, currentPhoto.imageUrl)}

            {/* Subtle Film Grain Vignette */}
            <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-black/20 via-transparent to-transparent" />
          </div>

          {/* Polaroid Caption Area */}
          <div className="pt-2.5 pb-0.5 flex flex-col justify-between flex-1">
            <div>
              <div className="flex items-center justify-between gap-2">
                <h3 className="font-serif font-bold text-sm text-stone-900 tracking-tight">
                  {currentPhoto.title}
                </h3>
                <span className="text-[10px] font-mono text-stone-500 font-semibold tracking-wide shrink-0">
                  {currentPhoto.date}
                </span>
              </div>
              <p className="mt-1 text-xs text-stone-700 font-serif italic leading-relaxed">
                "{currentPhoto.caption}"
              </p>
            </div>

            {/* Bottom Card Footer with Delete Button & Pagination */}
            <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-stone-200/80">
              <span className="text-[10px] font-mono tracking-widest uppercase text-stone-500 flex items-center gap-1">
                <Heart className="w-2.5 h-2.5 text-rose-500 fill-rose-500" />
                <span>Memories of Fati</span>
              </span>

              {/* Delete Button for current photo (including 2nd pic, 1st pic, etc.) & Slide count */}
              <div className="flex items-center gap-2">
                <button
                  id="delete-current-polaroid-btn"
                  onClick={e => {
                    e.stopPropagation();
                    sound.playButtonTap();
                    setDeleteConfirmId(currentPhoto.id);
                  }}
                  className="px-2 py-0.5 rounded-md text-stone-500 hover:text-rose-600 hover:bg-rose-50 border border-stone-200/70 hover:border-rose-200 transition-all cursor-pointer flex items-center gap-1 active:scale-95"
                  title="Delete this photo for all users"
                >
                  <Trash2 className="w-3 h-3 text-rose-500" />
                  <span className="text-[10px] font-sans font-medium text-stone-600 hover:text-rose-600">Delete</span>
                </button>

                <span className="text-[10px] font-mono text-stone-500">
                  {currentIndex + 1} / {photos.length}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Swipe & Navigation Controls */}
      {photos.length > 0 && (
        <div className="flex items-center justify-between w-full max-w-[310px] sm:max-w-[340px] mt-3.5 px-2">
          <button
            onClick={handlePrev}
            disabled={photos.length <= 1}
            className="min-h-[44px] min-w-[44px] rounded-full bg-white/[0.08] hover:bg-white/[0.16] border border-white/10 text-slate-200 flex items-center justify-center cursor-pointer transition-all hover:scale-105 active:scale-95 disabled:opacity-30 disabled:pointer-events-none"
            title="Previous photo"
            aria-label="Previous photo"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          {/* Dot Indicators */}
          <div className="flex items-center gap-1.5">
            {photos.map((_, idx) => (
              <button
                key={idx}
                onClick={() => {
                  sound.playButtonTap();
                  setCurrentIndex(idx);
                }}
                aria-label={`Go to photo ${idx + 1}`}
                className={`h-2.5 rounded-full transition-all cursor-pointer ${
                  idx === currentIndex
                    ? 'w-6 bg-[#d4af37] shadow-[0_0_8px_rgba(212,175,55,0.6)]'
                    : 'w-2.5 bg-white/20 hover:bg-white/40'
                }`}
              />
            ))}
          </div>

          <button
            onClick={handleNext}
            disabled={photos.length <= 1}
            className="min-h-[44px] min-w-[44px] rounded-full bg-white/[0.08] hover:bg-white/[0.16] border border-white/10 text-slate-200 flex items-center justify-center cursor-pointer transition-all hover:scale-105 active:scale-95 disabled:opacity-30 disabled:pointer-events-none"
            title="Next photo"
            aria-label="Next photo"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      )}

      {/* Confirmation Modal for Deleting Memory (Syncs across all users) */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative w-full max-w-sm rounded-2xl bg-[#141724] border border-rose-500/40 p-5 shadow-2xl text-slate-100 animate-zoomIn">
            <div className="flex items-center gap-2.5 mb-3 text-rose-400">
              <div className="w-9 h-9 rounded-full bg-rose-500/15 border border-rose-500/30 flex items-center justify-center">
                <Trash2 className="w-4 h-4 text-rose-400" />
              </div>
              <div>
                <h3 className="font-serif font-semibold text-sm text-white">Delete Photo</h3>
                <span className="text-[11px] text-slate-400">Will be removed for all users</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 font-serif leading-relaxed mb-4 p-3 bg-white/[0.03] rounded-xl border border-white/5">
              Are you sure you want to remove <span className="text-[#f5e6b3] font-semibold">"{photos.find(p => p.id === deleteConfirmId)?.title || 'this photo'}"</span>?
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => {
                  sound.playButtonTap();
                  setDeleteConfirmId(null);
                }}
                className="min-h-[40px] px-3.5 py-1.5 rounded-lg text-slate-300 hover:text-white text-xs font-serif transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                id="confirm-delete-photo-btn"
                onClick={() => handleDeletePhoto(deleteConfirmId)}
                className="min-h-[40px] px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-serif font-semibold text-xs tracking-wider uppercase transition-all shadow-md active:scale-95 cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add Your Own Polaroid Photo */}
      {isAdding && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative w-full max-w-sm rounded-2xl bg-[#141724] border border-amber-400/30 p-5 shadow-2xl text-slate-100 animate-zoomIn">
            <div className="flex items-center justify-between mb-4 border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#d4af37]" />
                <h3 className="font-serif font-semibold text-sm text-[#f5e6b3] uppercase tracking-wider">
                  Add Polaroid Memory
                </h3>
              </div>
              <button
                onClick={() => setIsAdding(false)}
                className="text-slate-400 hover:text-white min-h-[36px] min-w-[36px] flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-serif mb-1">Upload Photo (Optional)</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="w-full text-xs text-slate-400 file:mr-2 file:py-1 file:px-3 file:rounded-full file:border-0 file:text-xs file:bg-amber-500/20 file:text-amber-200 hover:file:bg-amber-500/30 cursor-pointer"
                />
                {newImageBase64 && (
                  <div className="mt-2 w-16 h-16 rounded-lg border border-white/20 overflow-hidden">
                    <img src={newImageBase64} alt="Preview" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>

              <div>
                <label className="block text-slate-300 font-serif mb-1">Memory Title</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  placeholder="e.g. Birthday Adventures"
                  className="w-full p-2.5 rounded-lg bg-black/40 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400/50"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-serif mb-1">Caption / Note</label>
                <textarea
                  value={newCaption}
                  onChange={e => setNewCaption(e.target.value)}
                  rows={2}
                  placeholder="Write a sweet memory or heartfelt caption..."
                  className="w-full p-2.5 rounded-lg bg-black/40 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400/50 resize-none font-serif"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-serif mb-1">Date</label>
                <input
                  type="text"
                  value={newDate}
                  onChange={e => setNewDate(e.target.value)}
                  placeholder="e.g. October 14"
                  className="w-full p-2.5 rounded-lg bg-black/40 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-amber-400/50 font-mono"
                />
              </div>
            </div>

            <div className="mt-5 flex items-center justify-end gap-2 pt-3 border-t border-white/10">
              <button
                onClick={() => setIsAdding(false)}
                className="min-h-[44px] px-3.5 py-1.5 rounded-lg text-slate-400 hover:text-white text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSavePhoto}
                disabled={!newCaption.trim()}
                className="min-h-[44px] px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 font-serif font-semibold text-xs tracking-wider uppercase transition-all disabled:opacity-40 cursor-pointer shadow-md active:scale-95"
              >
                Save Memory
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

